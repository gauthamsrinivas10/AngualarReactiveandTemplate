export default interface ISignup {
    "fullName": string
    "email": string
    "phone": string
    "password": string
    "confirmpassword": string    
}