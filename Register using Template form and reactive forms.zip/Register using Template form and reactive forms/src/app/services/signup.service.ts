import { Injectable } from '@angular/core';
import ISignup from '../interface/signup';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SignupService {

  constructor(private http : HttpClient) { }

  signup(signup : ISignup) {
    return this.http.post("http://localhost:4500/signup", signup)
   }
}

