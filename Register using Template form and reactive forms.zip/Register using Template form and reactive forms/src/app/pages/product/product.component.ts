import { Component, OnInit } from '@angular/core';
import IProduct from 'src/app/interface/product';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'employee-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  constructor(private http : HttpClient){}
  products : IProduct[] = [];
  ngOnInit(): void {
    this.http.get<IProduct[]>("http://localhost:4500/products").subscribe((data)=>{
      console.log(data);
      this.products = data;
  })
  }

}
