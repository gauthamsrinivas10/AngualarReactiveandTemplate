import { Component, OnInit , Input } from '@angular/core';
import IRegister from 'src/app/interface/register';
import { RegisterService } from 'src/app/services/register.service';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router'

@Component({
  selector: 'employee-registerform',
  templateUrl: './registerform.component.html',
  styleUrls: ['./registerform.component.css']
})
export class RegisterformComponent implements OnInit {
  
  form = new FormGroup({
    fullName :new  FormControl(''),
    phone :new  FormControl(''),
    email :new  FormControl(''),
    password :new  FormControl(''),
    confirmpassword :new  FormControl(''),
    address :new  FormControl(''),
    city :new  FormControl(''),
  })
  constructor(private registerform : RegisterService , private router : Router) { }
  @Input() firstName !: string;
  ngOnInit(): void {
    // this.registerform.getRegisterUsers(this.firstName).subscribe((data)=>{
    //   console.log(data);
    //   this.form.patchValue(data);
    // }
    // )
  }

  registerForm(){
    console.log(this.form.value)
    this.registerform.register(this.firstName ,this.form.value).subscribe((data)=>{
alert("New product added");
this.router.navigateByUrl(`/register/${this.firstName}`)
    
  })
}
}
