import { Directive , ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[employeeHighlight]'
})
export class HighlightDirective {

  constructor(private el : ElementRef) { }

  @HostListener("mouseover") mouseover(){
    console.log("mouseover")
    this.el.nativeElement.style.backgroundColor = "yellow"
      }
    
      @HostListener("mouseout") mouseout(){
        console.log("mouseout")
        this.el.nativeElement.style.backgroundColor = ""
      }
}
